import cv2
import json
import numpy as np
import mediapipe as mp
import tensorflow as tf


# ---------------------------------------
# 1. Load the trained deep-learning model
# ---------------------------------------

model = tf.keras.models.load_model("gesture_model.keras")

with open("labels.json", "r") as file:
    labels = json.load(file)


# ---------------------------------------
# 2. Smart-room device states
# ---------------------------------------

light = False
fan = False
tv = False


# ---------------------------------------
# 3. Gesture → command
# ---------------------------------------

commands = {
    "thumbs_up": "LIGHT ON",
    "thumbs_down": "LIGHT OFF",
    "open_palm": "STOP",
    "right": "NEXT",
    "left": "PREVIOUS"
}


# ---------------------------------------
# 4. MediaPipe setup
# ---------------------------------------

BaseOptions = mp.tasks.BaseOptions
HandLandmarker = mp.tasks.vision.HandLandmarker
HandLandmarkerOptions = mp.tasks.vision.HandLandmarkerOptions
VisionRunningMode = mp.tasks.vision.RunningMode

options = HandLandmarkerOptions(
    base_options=BaseOptions(
        model_asset_path="hand_landmarker.task"
    ),
    running_mode=VisionRunningMode.IMAGE,
    num_hands=1
)


# ---------------------------------------
# 5. Start webcam
# ---------------------------------------

with HandLandmarker.create_from_options(options) as landmarker:

    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Camera could not be opened.")
        exit()

    while True:

        success, frame = cap.read()

        if not success:
            break

        frame = cv2.flip(frame, 1)

        rgb_frame = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB
        )

        mp_image = mp.Image(
            image_format=mp.ImageFormat.SRGB,
            data=rgb_frame
        )

        result = landmarker.detect(mp_image)

        gesture = "No hand"
        confidence = 0.0
        command = "Waiting..."

        if result.hand_landmarks:

            hand = result.hand_landmarks[0]

            # Extract landmarks
            landmarks = []

            for landmark in hand:
                landmarks.append([
                    landmark.x,
                    landmark.y,
                    landmark.z
                ])

            landmarks = np.array(
                landmarks,
                dtype=np.float32
            )

            # Same preprocessing as training
            landmarks = landmarks - landmarks[0:1, :]

            scale = np.max(
                np.linalg.norm(landmarks, axis=1)
            )

            if scale != 0:
                landmarks = landmarks / scale

            features = landmarks.reshape(1, 63)

            # Predict gesture
            prediction = model.predict(
                features,
                verbose=0
            )[0]

            predicted_index = np.argmax(prediction)

            gesture = labels[predicted_index]

            confidence = float(
                prediction[predicted_index]
            )

            command = commands.get(
                gesture,
                "UNKNOWN"
            )

            # ---------------------------------------
            # Simulated smart-room actions
            # ---------------------------------------

            if confidence > 0.80:

                if gesture == "thumbs_up":
                    light = True

                elif gesture == "thumbs_down":
                    light = False

            # ---------------------------------------
            # Draw hand landmarks
            # ---------------------------------------

            for landmark in hand:

                x = int(
                    landmark.x * frame.shape[1]
                )

                y = int(
                    landmark.y * frame.shape[0]
                )

                cv2.circle(
                    frame,
                    (x, y),
                    5,
                    (0, 255, 0),
                    -1
                )


        # ---------------------------------------
        # Dashboard
        # ---------------------------------------

        cv2.rectangle(
            frame,
            (0, 0),
            (frame.shape[1], 190),
            (30, 30, 30),
            -1
        )

        cv2.putText(
            frame,
            "SMART ROOM CONTROL SYSTEM",
            (20, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Gesture: {gesture}",
            (20, 70),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 255, 0),
            2
        )

        cv2.putText(
            frame,
            f"Confidence: {confidence * 100:.1f}%",
            (20, 100),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Command: {command}",
            (20, 130),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 255, 255),
            2
        )

        light_status = "ON" if light else "OFF"
        fan_status = "OFF"
        tv_status = "OFF"

        cv2.putText(
            frame,
            f"LIGHT: {light_status}",
            (20, 165),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"FAN: {fan_status}",
            (190, 165),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"TV: {tv_status}",
            (330, 165),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2
        )

        cv2.imshow(
            "Smart Room Dashboard",
            frame
        )

        # Press Q to quit
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()