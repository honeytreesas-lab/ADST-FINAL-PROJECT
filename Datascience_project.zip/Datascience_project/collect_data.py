import cv2
import mediapipe as mp
import csv
import os

BaseOptions = mp.tasks.BaseOptions
HandLandmarker = mp.tasks.vision.HandLandmarker
HandLandmarkerOptions = mp.tasks.vision.HandLandmarkerOptions
VisionRunningMode = mp.tasks.vision.RunningMode

GESTURES = {
    "1": "thumbs_up",
    "2": "thumbs_down",
    "3": "open_palm",
    "4": "right",
    "5": "left",
    "6": "no_gesture"
}

options = HandLandmarkerOptions(
    base_options=BaseOptions(
        model_asset_path="hand_landmarker.task"
    ),
    running_mode=VisionRunningMode.IMAGE,
    num_hands=1
)

os.makedirs("dataset", exist_ok=True)

with HandLandmarker.create_from_options(options) as landmarker:

    cap = cv2.VideoCapture(0)

    current_gesture = None

    while True:
        success, frame = cap.read()

        if not success:
            print("Camera could not be opened")
            break

        frame = cv2.flip(frame, 1)

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        mp_image = mp.Image(
            image_format=mp.ImageFormat.SRGB,
            data=rgb
        )

        result = landmarker.detect(mp_image)

        if result.hand_landmarks and current_gesture:

            hand = result.hand_landmarks[0]

            row = [current_gesture]

            for landmark in hand:
                row.append(landmark.x)
                row.append(landmark.y)
                row.append(landmark.z)

            file_path = "dataset/gestures.csv"

            file_exists = os.path.isfile(file_path)

            with open(file_path, "a", newline="") as file:
                writer = csv.writer(file)

                if not file_exists:
                    writer.writerow(
                        ["gesture"] +
                        [f"{axis}{i}" for i in range(1, 22)
                         for axis in ["x", "y", "z"]]
                    )

                writer.writerow(row)

            cv2.putText(
                frame,
                f"Recording: {current_gesture}",
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )

        cv2.putText(
            frame,
            "1:Thumbs Up  2:Thumbs Down  3:Open Palm",
            (20, 450),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            "4:Right  5:Left   6:No Gesture  Q:Quit",
            (20, 480),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2
        )

        cv2.imshow("Dataset Collection", frame)

        key = cv2.waitKey(1) & 0xFF

        if key == ord("1"):
            current_gesture = "thumbs_up"

        elif key == ord("2"):
            current_gesture = "thumbs_down"

        elif key == ord("3"):
            current_gesture = "open_palm"

        elif key == ord("4"):
            current_gesture = "right"

        elif key == ord("5"):
            current_gesture = "left"

        elif key == ord("6"):
            current_gesture = "no_gesture"

        elif key == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()