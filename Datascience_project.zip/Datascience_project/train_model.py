import csv
import json
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers


# ---------------------------------------
# 1. Load the dataset
# ---------------------------------------

file_path = "dataset/gestures.csv"

features = []
labels = []

label_names = [
    "thumbs_up",
    "thumbs_down",
    "open_palm",
    "right",
    "left"
    
]

label_to_number = {
    name: i for i, name in enumerate(label_names)
}

with open(file_path, "r", newline="") as file:
    reader = csv.reader(file)

    # Skip header
    next(reader)

    for row in reader:
        gesture = row[0]
        values = [float(x) for x in row[1:]]

        if gesture in label_to_number:
            features.append(values)
            labels.append(label_to_number[gesture])


X = np.array(features, dtype=np.float32)
y = np.array(labels, dtype=np.int32)

print("Dataset loaded successfully!")
print("Total samples:", len(X))
print("Number of features:", X.shape[1])
print("Number of classes:", len(label_names))


# ---------------------------------------
# 2. Preprocess hand landmarks
# ---------------------------------------

# Each sample contains:
# 21 landmarks × 3 values (x, y, z)
X = X.reshape(-1, 21, 3)

# Make the wrist (landmark 0) the reference point
X = X - X[:, 0:1, :]

# Scale each hand so different hand sizes
# have less effect on the model
scale = np.max(np.linalg.norm(X, axis=2), axis=1)

# Avoid division by zero
scale[scale == 0] = 1

X = X / scale[:, np.newaxis, np.newaxis]

# Convert back to 63 features
X = X.reshape(-1, 63)


# ---------------------------------------
# 3. Create a stratified train/test split
# ---------------------------------------

np.random.seed(42)

train_indices = []
test_indices = []

for class_number in range(len(label_names)):

    class_indices = np.where(y == class_number)[0]

    np.random.shuffle(class_indices)

    split_point = int(len(class_indices) * 0.80)

    train_indices.extend(class_indices[:split_point])
    test_indices.extend(class_indices[split_point:])


train_indices = np.array(train_indices)
test_indices = np.array(test_indices)

np.random.shuffle(train_indices)
np.random.shuffle(test_indices)

X_train = X[train_indices]
y_train = y[train_indices]

X_test = X[test_indices]
y_test = y[test_indices]

print("Training samples:", len(X_train))
print("Testing samples:", len(X_test))


# ---------------------------------------
# 4. Build the neural network
# ---------------------------------------

model = keras.Sequential([
    layers.Input(shape=(63,)),

    layers.Dense(128, activation="relu"),
    layers.Dropout(0.20),

    layers.Dense(64, activation="relu"),
    layers.Dropout(0.20),

    layers.Dense(32, activation="relu"),

    layers.Dense(5, activation="softmax")

  


])


# ---------------------------------------
# 5. Compile the model
# ---------------------------------------

model.compile(
    optimizer="adam",
    loss="sparse_categorical_crossentropy",
    metrics=["accuracy"]
)


# ---------------------------------------
# 6. Train the model
# ---------------------------------------

print("\nStarting model training...\n")

early_stopping = keras.callbacks.EarlyStopping(
    monitor="val_loss",
    patience=5,
    restore_best_weights=True
)

history = model.fit(
    X_train,
    y_train,
    epochs=30,
    batch_size=32,
    validation_split=0.20,
    callbacks=[early_stopping],
    verbose=1
)


# ---------------------------------------
# 7. Evaluate the model
# ---------------------------------------

test_loss, test_accuracy = model.evaluate(
    X_test,
    y_test,
    verbose=0
)

print("\n--------------------------------")
print("MODEL EVALUATION")
print("--------------------------------")
print(f"Test Accuracy: {test_accuracy * 100:.2f}%")
print(f"Test Loss: {test_loss:.4f}")


# ---------------------------------------
# 8. Save the trained model
# ---------------------------------------

model.save("gesture_model.keras")

with open("labels.json", "w") as file:
    json.dump(label_names, file)

print("\nModel saved as: gesture_model.keras")
print("Labels saved as: labels.json")


# ---------------------------------------
# 9. Show confusion matrix
# ---------------------------------------

predictions = model.predict(X_test, verbose=0)
predicted_classes = np.argmax(predictions, axis=1)

confusion_matrix = np.zeros(
    (len(label_names), len(label_names)),
    dtype=int
)

for actual, predicted in zip(y_test, predicted_classes):
    confusion_matrix[actual][predicted] += 1

print("\nConfusion Matrix:")
print(confusion_matrix)

print("\nClass order:")
for i, name in enumerate(label_names):
    print(i, "=", name)

print("\nTraining completed successfully!")