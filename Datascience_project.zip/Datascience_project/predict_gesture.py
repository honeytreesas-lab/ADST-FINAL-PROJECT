import cv2
import json
import numpy as np
import mediapipe as mp
import tensorflow as tf


# ---------------------------------------
# 1. Load trained model
# ---------------------------------------

model = tf.keras.models.load_model("gesture_model.keras")

with open("labels.json", "r") as file:
    labels = json.load(file)

print("Model loaded successfully!")
print("Gestures:", labels)


# ---------------------------------------
# 2. Set up MediaPipe Hand Landmarker
# ---------------------------------------

BaseOptions = mp.tasks.BaseOptions
HandLandmarker = mp.tasks.vision.HandLandmarker
HandLandmarkerOptions = mp.tasks.vision.HandLandmarkerOptions
VisionRunningMode = mp.tasks.vision.RunningMode

options = HandLandmarkerOptions(
    base_options=BaseOptions(
        model_asset_path="hand_landmarker.task"
    ),
    running_mode=VisionRunningMode.IMAGE,
    num_hands=1
)


# ---------------------------------------
# 3. Gesture → Smart Room Command
# ---------------------------------------

commands = {
    "thumbs_up": "LIGHT ON",
    "thumbs_down": "LIGHT OFF",
    "open_palm": "STOP",
    "right": "NEXT",
    "left": "PREVIOUS"
}


# ---------------------------------------
# 4. Start webcam
# ---------------------------------------

with HandLandmarker.create_from_options(options) as landmarker:

    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Camera could not be opened.")
        exit()

    while True:

        success, frame = cap.read()

        if not success:
            print("Could not read camera frame.")
            break

        # Mirror the camera
        frame = cv2.flip(frame, 1)

        # Convert BGR → RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        mp_image = mp.Image(
            image_format=mp.ImageFormat.SRGB,
            data=rgb_frame
        )

        # Detect hand
        result = landmarker.detect(mp_image)

        gesture = "No hand"
        confidence = 0.0
        command = "Waiting..."

        if result.hand_landmarks:

            hand = result.hand_landmarks[0]

            # ---------------------------------------
            # Extract 21 landmarks
            # ---------------------------------------

            landmarks = []

            for landmark in hand:
                landmarks.append([
                    landmark.x,
                    landmark.y,
                    landmark.z
                ])

            landmarks = np.array(
                landmarks,
                dtype=np.float32
            )

            # ---------------------------------------
            # Same preprocessing used during training
            # ---------------------------------------

            landmarks = landmarks - landmarks[0:1, :]

            scale = np.max(
                np.linalg.norm(landmarks, axis=1)
            )

            if scale != 0:
                landmarks = landmarks / scale

            # Convert to 63 features
            features = landmarks.reshape(1, 63)

            # ---------------------------------------
            # Predict gesture
            # ---------------------------------------

            prediction = model.predict(
                features,
                verbose=0
            )[0]

            predicted_index = np.argmax(prediction)

            gesture = labels[predicted_index]
            confidence = float(prediction[predicted_index])

            command = commands.get(
                gesture,
                "UNKNOWN"
            )

            # ---------------------------------------
            # Draw hand landmarks
            # ---------------------------------------

            for landmark in hand:

                x = int(
                    landmark.x * frame.shape[1]
                )

                y = int(
                    landmark.y * frame.shape[0]
                )

                cv2.circle(
                    frame,
                    (x, y),
                    5,
                    (0, 255, 0),
                    -1
                )

        # ---------------------------------------
        # Display prediction
        # ---------------------------------------

        cv2.putText(
            frame,
            f"Gesture: {gesture}",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            (0, 255, 0),
            2
        )

        cv2.putText(
            frame,
            f"Confidence: {confidence * 100:.1f}%",
            (20, 80),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Command: {command}",
            (20, 120),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            (0, 255, 255),
            2
        )

        cv2.imshow(
            "Smart Room - Gesture Recognition",
            frame
        )

        # Press Q to quit
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()