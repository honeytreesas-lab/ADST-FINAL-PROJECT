from flask import Flask, Response, render_template,request,redirect,session
import cv2
import json
import numpy as np
import mediapipe as mp
import tensorflow as tf

app = Flask(__name__)
app.secret_key = "smart-room-secret"

# Load the trained deep-learning model
model = tf.keras.models.load_model("gesture_model.keras")

# Load gesture names
with open("labels.json", "r") as file:
    labels = json.load(file)

# Smart-room commands
commands = {
    "thumbs_up": "LIGHT ON",
    "thumbs_down": "LIGHT OFF",
    "open_palm": "STOP",
    "right": "NEXT",
    "left": "PREVIOUS"
}

# Smart-room status
light = False
fan = False
tv = False


# MediaPipe setup
BaseOptions = mp.tasks.BaseOptions
HandLandmarker = mp.tasks.vision.HandLandmarker
HandLandmarkerOptions = mp.tasks.vision.HandLandmarkerOptions
VisionRunningMode = mp.tasks.vision.RunningMode

options = HandLandmarkerOptions(
    base_options=BaseOptions(
        model_asset_path="hand_landmarker.task"
    ),
    running_mode=VisionRunningMode.IMAGE,
    num_hands=1
)


# Open webcam
camera = cv2.VideoCapture(0)


def generate_frames():

    global light

    with HandLandmarker.create_from_options(options) as landmarker:

        while True:

            success, frame = camera.read()

            if not success:
                break

            frame = cv2.flip(frame, 1)

            rgb_frame = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            mp_image = mp.Image(
                image_format=mp.ImageFormat.SRGB,
                data=rgb_frame
            )

            result = landmarker.detect(mp_image)

            gesture = "No hand"
            confidence = 0.0
            command = "Waiting..."

            if result.hand_landmarks:

                hand = result.hand_landmarks[0]

                # Get 21 hand landmarks
                landmarks = []

                for landmark in hand:
                    landmarks.append([
                        landmark.x,
                        landmark.y,
                        landmark.z
                    ])

                landmarks = np.array(
                    landmarks,
                    dtype=np.float32
                )

                # Same preprocessing used during training
                landmarks = landmarks - landmarks[0:1, :]

                scale = np.max(
                    np.linalg.norm(landmarks, axis=1)
                )

                if scale != 0:
                    landmarks = landmarks / scale

                features = landmarks.reshape(1, 63)

                # Predict gesture
                prediction = model.predict(
                    features,
                    verbose=0
                )[0]

                predicted_index = np.argmax(prediction)

                gesture = labels[predicted_index]

                confidence = float(
                    prediction[predicted_index]
                )

                command = commands.get(
                    gesture,
                    "UNKNOWN"
                )

                # Smart-room simulation
                if confidence > 0.80:

                    if gesture == "thumbs_up":
                        light = True

                    elif gesture == "thumbs_down":
                        light = False

                # Draw landmarks
                for landmark in hand:

                    x = int(
                        landmark.x * frame.shape[1]
                    )

                    y = int(
                        landmark.y * frame.shape[0]
                    )

                    cv2.circle(
                        frame,
                        (x, y),
                        5,
                        (0, 255, 0),
                        -1
                    )

            # Display information on camera
            cv2.putText(
                frame,
                "SMART ROOM AI",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (255, 255, 255),
                2
            )

            cv2.putText(
                frame,
                f"Gesture: {gesture}",
                (20, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )

            cv2.putText(
                frame,
                f"Confidence: {confidence * 100:.1f}%",
                (20, 105),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )

            cv2.putText(
                frame,
                f"Command: {command}",
                (20, 140),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2
            )

            # Convert frame to JPEG
            ret, buffer = cv2.imencode(
                ".jpg",
                frame
            )

            frame_bytes = buffer.tobytes()

            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n"
                + frame_bytes
                + b"\r\n"
            )


@app.route("/", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        if username == "admin" and password == "1234":
            session["logged_in"] = True
            return redirect("/dashboard")

    return render_template("login.html")



@app.route("/dashboard")
def dashboard():

    if not session.get("logged_in"):
        return redirect("/")

    return render_template("index.html")

@app.route("/video_feed")
def video_feed():
    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )
@app.route("/logout")
def logout():
    return render_template("login.html")
@app.route("/performance")
def performance():
    return render_template("performance.html")
@app.route("/live")
def live():
    return render_template("live.html")
@app.route("/gestures")
def gestures():
    return render_template("gestures.html")
@app.route("/smart-room")
def smart_room():
    return render_template("smart_room.html")

if __name__ == "__main__":
    app.run(
        debug=True,
        host="127.0.0.1",
        port=5000
    )
